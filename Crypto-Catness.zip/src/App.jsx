import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';
import { Program, Provider, web3 } from '@project-serum/anchor';
import React, { useEffect, useState } from 'react';
import './App.css';
import idl from './idl.json';
import kp from './keypair.json'
import { Buffer } from 'buffer';
window.Buffer = Buffer;


// SystemProgram is a reference to the Solana runtime!
const { SystemProgram, Keypair } = web3;

// Keypair for the account that will hold the GIF data
const arr = Object.values(kp._keypair.secretKey)
const secret = new Uint8Array(arr)
const baseAccount = web3.Keypair.fromSecretKey(secret)

// Get program id from the IDL file
const programID = new PublicKey(idl.metadata.address);

// Set network to Devnet
const network = clusterApiUrl('devnet');

// Controls how to acknowledge when a transaction is done
const opts = {
  preflightCommitment: "processed"
}

const TEST_GIFS = [
  'https://media0.giphy.com/media/hGFiFeUFnvUPjW8lEZ/giphy.gif?cid=790b761177e308c71b2f18465fb6a4006e07fece127e3582&rid=giphy.gif&ct=g',
  'https://media3.giphy.com/media/vVegyymxA90fkY8jkE/giphy.gif?cid=790b76118ec2b1b9fc7d0809c680dff115ce3241ec7b8dc9&rid=giphy.gif&ct=g',
  'https://media3.giphy.com/media/h53vStwNbmOpkDuC7w/giphy.gif?cid=790b7611fb1048db72010452b15d56bada3b1cce32644bc4&rid=giphy.gif&ct=g',
  'https://media1.giphy.com/media/13vSD7ajIJwgb6/giphy.gif?cid=790b76118742da6de7a4a7265b7e2f19f29d031638b819ca&rid=giphy.gif&ct=g',
  'https://media0.giphy.com/media/tXbIzgtLCTxHa/giphy.gif?cid=790b76115bb8db76c08cc9a144685a2aa428aa402db91925&rid=giphy.gif&ct=g',
  'https://media4.giphy.com/media/auvPdJqCpMA4E/giphy.gif?cid=790b761106594ee01002281bf9e96615fad0e480390f88dc&rid=giphy.gif&ct=g',
  'https://media1.giphy.com/media/exgXK4yzfvnLG/giphy.gif?cid=790b7611b1834781f535e9c97c31959e2c1edd4ee6d9a67a&rid=giphy.gif&ct=g',
  'https://media2.giphy.com/media/gx54W1mSpeYMg/giphy.gif?cid=790b7611ec5e038a3b5ddfbd5f3f0737db2d4ca07089aa02&rid=giphy.gif&ct=g'
]


const App = () => {
  
  // State
  const [walletAddress, setWalletAddress] = useState(null);
  const [inputValue, setInputValue] = useState('');
  const [gifList, setGifList] = useState([]);
  /*
  * The following function determines if a Phantom Wallet is connected.
  * Checks the DOM window object for injected solana object, then check if Phantom
  */
  
  const checkIfWalletIsConnected = async () => {
    try {
      const { solana } = window;

      if (solana){
        if (solana.isPhantom) {
          console.log('Phantom wallet found!');
          const response = await solana.connect({ onlyIfTrusted: true });
          console.log(
            'Connected with Public Key:',
            response.publicKey.toString()
          );
          // Set the user's publicKey in state to be used later
          setWalletAddress(response.publicKey.toString());
        }
      } else {
          alert('Solana object not found! Get a Phantom Wallet 👻')
      }
    } catch (error) {
        console.error(error);
    }
  };

  const connectWallet = async () => {
    const { solana } = window;

    if (solana) {
      const response = await solana.connect();
      console.log('Connected with Public Key:', response.publicKey.toString());
      setWalletAddress(response.publicKey.toString());
    }
  };

  const onInputChange = (event) => {
    const {value} = event.target;
    setInputValue(value);
  };

  const getProvider = () => {
    const connection = new Connection(network, opts.preflightCommitment);
    const provider = new Provider(
      connection, window.solana, opts.preflightCommitment,
    );
      return provider;
  }

   const createGifAccount = async () => {
    try {
      const provider = getProvider();
      const program = new Program(idl, programID, provider);
      console.log("ping")
      await program.rpc.startStuffOff({
        accounts: {
          baseAccount: baseAccount.publicKey,
          user: provider.wallet.publicKey,
          systemProgram: SystemProgram.programId,
        },
        signers: [baseAccount]
      });
      console.log("Created a new BaseAccount w/ address:", baseAccount.publicKey.toString())
      await getGifList();
  
    } catch(error) {
      console.log("Error creating BaseAccount account:", error)
    }
  }
  

  const sendGif = async () => {
    if (inputValue.length === 0) {
      console.log("No gif link given!")
      return
    }
    setInputValue('');
    console.log('Gif link:', inputValue);
    try {
      const provider = getProvider();
      const program = new Program(idl, programID, provider);

      await program.rpc.addGif(inputValue, {
        accounts: {
          baseAccount: baseAccount.publicKey,
          user: provider.wallet.publicKey,
        },
      });
      console.log("GIF successfully sent to program", inputValue)

      await getGifList();
    } catch (error) {
      console.log("Error sending GIF:", error)
    }
  };
  // Render this UI when the user hasn't connected yet

  const renderNotConnectedContainer = () => (
    <button
      className="cta-button connect-wallet-button" 
      onClick={connectWallet}
    >
      Connect to Phantom Wallet
    </button>
  );

  // Render the GIF grid when the user connects
  const renderConnectedContainer = () => {
    if (gifList === null) {
      return (
        <div className="connected-container">
            <button className="cta-button submit-gif-button" onClick={createGifAccount}>
              Do One-Time Initialization For GIF Program Account
            </button>
        </div>
      )
    }
    else {
      return (
            <div className="connected-container">
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  sendGif();
                }}
              >
              <input 
                type="text" 
                placeholder="Enter gif link!"
                value={inputValue}
                onChange={onInputChange}
              />
              <button type="submit" className="cta-button submit-gif-button">Submit</button>
                </form>
              <div className="gif-grid">
                {gifList.map((item, index) => (
                  <div className="gif-item" key={index}>
                    <img src={item.gifLink} />
                  </div>
                ))}
              </div>
            </div>
      )
    } 

  }
  
  /*
  * Call the function on load.
  * UseEffects
  */
  useEffect(() => {
    const onLoad = async () => {
      await checkIfWalletIsConnected();
    };
    window.addEventListener('load', onLoad);
    return () => window.removeEventListener('load', onLoad);
  }, []);


const getGifList = async () => {
  try {
    const provider = getProvider();
    const program = new Program(idl, programID, provider);
    const account = await program.account.baseAccount.fetch(baseAccount.publicKey);
  
    console.log("Got the account", account)
    setGifList(account.gifList)
  } catch (error) {
    console.log("Error in getGifList: ", error)
    setGifList(null);
  }
}


  
  useEffect(() => {
    if (walletAddress) {
      console.log('Fetching GIF list...');
      getGifList()
    }
  }, [walletAddress]);
  
  return (
    <div className="App">
      <div className="container">
        <div className="header-container">
          <p className="header">(｡◕‿‿◕｡) Crypto Catness</p>
          <p className="sub-text">
            View your cat collection in the metaverse ✨
          </p>
          {/* Conditional rendering: This condition shows this button only if we don't have a wallet address */}
          {!walletAddress && renderNotConnectedContainer()}
          {walletAddress && renderConnectedContainer()}
        </div>
        <div className="footer-container">

        </div>
      </div>
    </div>
  );
};

export default App;
